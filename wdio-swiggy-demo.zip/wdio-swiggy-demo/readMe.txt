#installation

Do a npm i in the folder where package.json file is present

install chrome driver through the below command in powershell


#Pre requisite

run chromedriver in port =44444

cmd chromedriver --port=4444


#Run test scripts

run the below command in the project root folder

npm run test

