import HomePage from "../pageObjects/homePage";
import equal from "assert";

describe('Swiggy Home Page', () => {

    describe('Validate Home Page', () => {

        beforeAll(() => {
            browser.url('/');
            browser.maximizeWindow();
        });

        it('Validate home page title', () => {
            browser.saveScreenshot('./test/reports/home/1_Validate_Title.png');
            equal(HomePage.getTitle, 'Order food online from India\'s best food delivery service. Order from restaurants near you');
        });

        it('Validate the selected location', () => {
            HomePage.locationTextBox.click();
            HomePage.locationTextBox.setValue("poonamallee");
            HomePage.firstLocation.click();
            browser.pause(1000);
            browser.saveScreenshot('./test/reports/home/2_Validate_selected_location.png');
            expect(HomePage.locationSelected.isDisplayed()).toEqual(true);

        });
    });


    describe('Popular Brands', () => {

        beforeAll(() => {
            HomePage.popularBrands(1).click();
            browser.pause(500);
            HomePage.recommendedMenuBtn.click();
            browser.pause(100);
            HomePage.addFoodItem(1).click();
        });

        it('Validate add to cart from a popular restaurant', () => {
            browser.pause(1000);
            browser.saveScreenshot('./test/reports/home/3_validate_ADD_tocart.png');
            expect(HomePage.checkoutButton.isDisplayed()).toEqual(true);
        });

    });



});