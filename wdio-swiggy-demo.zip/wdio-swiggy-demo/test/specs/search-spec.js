import HomePage from "../pageObjects/homePage";
import equal from "assert";

describe('Swiggy search page', () => {

        beforeAll(() => {
            browser.url('/');
            browser.maximizeWindow();
            HomePage.locationTextBox.click();
            HomePage.locationTextBox.setValue("poonamallee");
            HomePage.firstLocation.click();
            browser.pause(500);
            browser.saveScreenshot('./test/reports/search/1_Validate_selected_location.png');
        });

    describe('Verify swiggy restaurant search', () => {

        beforeAll(() => {
            HomePage.searchButton.click();
            browser.pause(500);
            HomePage.searchTextBox.setValue('SS Pandiyan');
            browser.pause(3000);
            browser.saveScreenshot('./test/reports/search/2_Validate_Search_results.png');
            HomePage.firstListedRestaurant.click();
            HomePage.recommendedMenuBtn.click();
            browser.pause(100);
            HomePage.addFoodItem(1).click();
            browser.pause(2500);
        });


        it('Validate whether the item is added to the cart', () => {
            browser.saveScreenshot('./test/reports/search/3_Validate_Search_ADD_toCart_.png');
            expect(HomePage.checkoutButton.isDisplayed()).toEqual(true);
        });
    });
});