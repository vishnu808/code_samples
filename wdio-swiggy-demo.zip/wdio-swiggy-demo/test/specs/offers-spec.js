import HomePage from "../pageObjects/homePage";
import OffersPage from '../pageObjects/offersPage';

describe('Swiggy Offers Page', () => {

        beforeAll(() => {
            browser.url('/');
            browser.maximizeWindow();
            HomePage.locationTextBox.click();
            HomePage.locationTextBox.setValue("poonamallee");
            HomePage.firstLocation.click();
            browser.saveScreenshot('./test/reports/offers/1_Validate_selected_location.png');
        });

    describe('Validate the offers page', () => {

        beforeAll(() => {
            OffersPage.OffersLink.click();
        });

        it('Validate Offers URL', () => {
            browser.saveScreenshot('./test/reports/offers/2_Validate_offers_URL.png');
            expect(browser.getUrl()).toContain('/offers/restaurant');
            
        });

        it('Validate Restaurant Offers', () => {
            browser.saveScreenshot('./test/reports/offers/3_Validate_Restaurant_offers.png');
            expect(OffersPage.restaurantOffers.getText()).toEqual('Restaurant offers');

        });

        it('Validate Payment Offers', () => {
            browser.saveScreenshot('./test/reports/offers/4_Validate_payment_offers.png');
            expect(OffersPage.payementOffers.getText()).toEqual('Payment offers/Coupons');
        });

    });
});