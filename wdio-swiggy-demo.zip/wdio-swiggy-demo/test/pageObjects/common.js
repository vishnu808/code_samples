export default class Common {
    open (subUrl) {
      browser.url(subUrl)
    }
  }
  