
class OffersPage {


    get OffersLink() {
        return $('a[href="/offers/restaurant"]');
    }

    
    get restaurantOffers() {
        return $('#restaurant');
    }

    
    get payementOffers() {
        return $('#payment');
    }
}

export default new OffersPage()