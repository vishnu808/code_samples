
class HomePage {


    get locationTextBox() {
        return $('//input[@id="location"]')
    }

    get firstLocation() {
        return $('//input[@id="location"]/parent::div//following-sibling::div[2]//div[1]/span[2]')
    }

    get navigationBar() {
        return $('.global-nav a[title="Swiggy"]+div');
    }
    get locationSelected() {
        return this.navigationBar.$('//span[contains(text(), "Poonamallee")]');
    }

    get getTitle() {
        return browser.getTitle();
    }

    get searchButton() {
        return $('.global-nav li a[href="/search"]');
    }

    get searchTextBox() {
        return $('.icon-magnifier+input[type="text"]');
    }

    get firstListedRestaurant() {
        return $$('//a[starts-with(@href,"/restaurants")]')[0];
    }

    get recommendedMenuBtn() {
        return $('//div[@id="menu-content"]//a[@href]//div[contains(text(),"Recommend")]');
    }

    get recommendedHeader() {
        return $('//h2[contains(text(),"Recommended")]');
    }

    addFoodItem(index) {
        return this.recommendedHeader.$$('//following-sibling::div//div[@itemtype]//div[contains(text(),"ADD")]')[index]
    }

    popularBrands(index) {
        return $(`//div[@id="open_filter"]//div[starts-with(@id,"filter")]/div[contains(text(),"Popular")]//following-sibling::div//div/a[starts-with(@href,"/restaurants")][${index}]`);
    }

    get checkoutButton() {
        return $(`//div[contains(text(),"Checkout")]`);
    }

    
}

export default new HomePage()